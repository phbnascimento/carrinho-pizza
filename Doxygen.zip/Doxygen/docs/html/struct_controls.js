var struct_controls =
[
    [ "sw", "struct_controls.html#a14d0fa1de5e626d1dc1cba236dff2379", null ],
    [ "trigger", "struct_controls.html#acf3f4cb783a1d6a1acbd0f3656620b7b", null ],
    [ "x", "struct_controls.html#a0958b9cae1f60c23a4d0309058b45357", null ],
    [ "y", "struct_controls.html#a8a1da9fdf679e6e1d17f310420755d94", null ]
];