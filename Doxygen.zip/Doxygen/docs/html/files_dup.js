var files_dup =
[
    [ "arduino", "dir_7957e4d193d4a425fd39fd4994c5caf1.html", "dir_7957e4d193d4a425fd39fd4994c5caf1" ],
    [ "carrinho", "dir_751a2ea2247ce4bb910fd3d3209aaf82.html", "dir_751a2ea2247ce4bb910fd3d3209aaf82" ],
    [ "controle", "dir_a94db699c8beb20a92e0a969ce56e755.html", "dir_a94db699c8beb20a92e0a969ce56e755" ],
    [ "main.c", "main_8c.html", "main_8c" ]
];