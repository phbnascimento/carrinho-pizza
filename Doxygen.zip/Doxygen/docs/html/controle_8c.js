var controle_8c =
[
    [ "Controls", "structControls.html", "structControls" ],
    [ "F_CPU", "controle_8c.html#a43bafb28b29491ec7f871319b5a3b2f8", null ],
    [ "HIGH", "controle_8c.html#a5bb885982ff66a2e0a0a45a8ee9c35e2", null ],
    [ "JS", "controle_8c.html#aea65463ec80bbae979a30002d5aa8558", null ],
    [ "JX", "controle_8c.html#a08ee2643fc201d0aa439a4bef60a8890", null ],
    [ "JY", "controle_8c.html#ab03428ee7292eb7bc1f40c08b91f49ab", null ],
    [ "LED1", "controle_8c.html#a8aa85ae9867fabf70ec72cd3bf6fb6b9", null ],
    [ "LED2", "controle_8c.html#ad09fe5bf321b9a2de26bd5e5b9af6424", null ],
    [ "LOW", "controle_8c.html#ab811d8c6ff3a505312d3276590444289", null ],
    [ "TRIGGER", "controle_8c.html#a86de85f5177dabb5ff712bf180db43aa", null ],
    [ "abs_int", "controle_8c.html#a3785cfdfc42be12ee699c8b8b4e4d01f", null ],
    [ "adc_read", "controle_8c.html#a7c3d687942e3acba4e53cac61d9e71ea", null ],
    [ "adc_setup", "controle_8c.html#af5e0a217880b6f6976ff1c2b1297f7a3", null ],
    [ "loop", "controle_8c.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "main", "controle_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "map", "controle_8c.html#aada2d75bc8a8c6eb845bd940eadfa3fd", null ],
    [ "pwm_setup", "controle_8c.html#a6b11f55ddc2f9d1125c97a47e4a799f6", null ],
    [ "pwm_write", "controle_8c.html#a0bf689abd3a20724062e39ce568130b1", null ],
    [ "setup", "controle_8c.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "address", "controle_8c.html#a4f926beded94616414d611d5c8099424", null ]
];