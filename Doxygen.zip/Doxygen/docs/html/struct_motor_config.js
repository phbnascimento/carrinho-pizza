var struct_motor_config =
[
    [ "id_motor", "struct_motor_config.html#ad5ef2b1985959b70abcebb2bc113ea81", null ],
    [ "invertido", "struct_motor_config.html#a51b81cc752c4db571d9bcb21b4bd4d0b", null ],
    [ "pino_pwm", "struct_motor_config.html#acf47d1ce2a3529902fef89ba67b46a6c", null ],
    [ "velocidade_atual", "struct_motor_config.html#a4c57e12d6c7846121c5371d59f125672", null ]
];