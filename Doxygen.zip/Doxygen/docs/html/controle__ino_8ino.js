var controle__ino_8ino =
[
    [ "Controls", "structControls.html", "structControls" ],
    [ "JS", "controle__ino_8ino.html#aea65463ec80bbae979a30002d5aa8558", null ],
    [ "JX", "controle__ino_8ino.html#a08ee2643fc201d0aa439a4bef60a8890", null ],
    [ "JY", "controle__ino_8ino.html#ab03428ee7292eb7bc1f40c08b91f49ab", null ],
    [ "LED1", "controle__ino_8ino.html#a8aa85ae9867fabf70ec72cd3bf6fb6b9", null ],
    [ "LED2", "controle__ino_8ino.html#ad09fe5bf321b9a2de26bd5e5b9af6424", null ],
    [ "TRIGGER", "controle__ino_8ino.html#a86de85f5177dabb5ff712bf180db43aa", null ],
    [ "loop", "controle__ino_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "radio", "controle__ino_8ino.html#a53cdd46f95419ffdcd44d3f0d6147b54", null ],
    [ "setup", "controle__ino_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "address", "controle__ino_8ino.html#ae0c0431bfc31dc095fb3215eaebf79ea", null ]
];