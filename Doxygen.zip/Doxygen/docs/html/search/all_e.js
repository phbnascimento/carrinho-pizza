var searchData=
[
  ['objetivos_0',['🎯 Objetivos',['../index.html#autotoc_md2',1,'']]],
  ['observe_5ftx_1',['OBSERVE_TX',['../carrinho_2nRF24L01_8h.html#a491468eaa7f2db84c152709b0b5fb1aa',1,'OBSERVE_TX:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a491468eaa7f2db84c152709b0b5fb1aa',1,'OBSERVE_TX:&#160;nRF24L01.h']]],
  ['on_2',['on',['../carrinho__ino_8ino.html#aaa928c9a62449f7946da1e32f66c70d2',1,'on:&#160;carrinho_ino.ino'],['../carrinho_8c.html#aaa928c9a62449f7946da1e32f66c70d2',1,'on:&#160;carrinho.c']]]
];
