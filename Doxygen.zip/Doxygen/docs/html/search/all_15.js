var searchData=
[
  ['x_0',['x',['../structControls.html#a0958b9cae1f60c23a4d0309058b45357',1,'Controls']]]
];
