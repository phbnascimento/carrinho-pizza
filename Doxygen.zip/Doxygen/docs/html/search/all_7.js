var searchData=
[
  ['gameover_0',['gameOver',['../carrinho__ino_8ino.html#a026d019671eda0cfe729200fc24d23ba',1,'carrinho_ino.ino']]],
  ['gigantes_20de_20mdf_20carro_20pizza_20🚗_1',['Gigantes de MDF - CARRO-PIZZA! 🚗',['../index.html',1,'']]]
];
