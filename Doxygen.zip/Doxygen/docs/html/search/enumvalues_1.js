var searchData=
[
  ['forward_0',['FORWARD',['../carrinho__ino_8ino.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4aa26736999186daf8146f809e863712a1',1,'FORWARD:&#160;carrinho_ino.ino'],['../carrinho_8c.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4aa26736999186daf8146f809e863712a1',1,'FORWARD:&#160;carrinho.c']]]
];
