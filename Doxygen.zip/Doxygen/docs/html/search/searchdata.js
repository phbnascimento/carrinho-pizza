var indexSectionsWithContent =
{
  0: "_abcdefghijlmnoprstuwxy🎯🔌🚀🚗🛠",
  1: "ct",
  2: "cmnr",
  3: "acdghilmnprstw",
  4: "_acdlmoprstxy",
  5: "dm",
  6: "bflr",
  7: "abcdefhijlmnoprstw",
  8: "cdghimopu🎯🔌🚀🚗🛠"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Estruturas de dados",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Enumerações",
  6: "Valores de enumerações",
  7: "Macros",
  8: "Páginas"
};

