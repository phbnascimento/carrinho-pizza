var searchData=
[
  ['left_0',['LEFT',['../carrinho__ino_8ino.html#a3bc45ff9023afee0cc287274e972d7ceadb45120aafd37a973140edee24708065',1,'LEFT:&#160;carrinho_ino.ino'],['../carrinho_8c.html#a3bc45ff9023afee0cc287274e972d7ceadb45120aafd37a973140edee24708065',1,'LEFT:&#160;carrinho.c']]]
];
