var searchData=
[
  ['motor_0',['Motor',['../carrinho__ino_8ino.html#a3bc45ff9023afee0cc287274e972d7ce',1,'Motor:&#160;carrinho_ino.ino'],['../carrinho_8c.html#a3bc45ff9023afee0cc287274e972d7ce',1,'Motor:&#160;carrinho.c']]]
];
