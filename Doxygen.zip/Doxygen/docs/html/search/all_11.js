var searchData=
[
  ['setup_0',['setup',['../carrinho__ino_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;carrinho_ino.ino'],['../controle__ino_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;controle_ino.ino'],['../controle_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;controle.c']]],
  ['setup_5faw_1',['SETUP_AW',['../carrinho_2nRF24L01_8h.html#af5ef355ba3eca336db1285cab353ddc2',1,'SETUP_AW:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#af5ef355ba3eca336db1285cab353ddc2',1,'SETUP_AW:&#160;nRF24L01.h']]],
  ['setup_5fretr_2',['SETUP_RETR',['../carrinho_2nRF24L01_8h.html#a2188309b3eceeae158dd64109cd919aa',1,'SETUP_RETR:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a2188309b3eceeae158dd64109cd919aa',1,'SETUP_RETR:&#160;nRF24L01.h']]],
  ['spi_5finit_3',['spi_init',['../carrinho_2nrf24__avr_8c.html#aa653f4dc3541758224a53eef3f04d490',1,'spi_init(void):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#aa653f4dc3541758224a53eef3f04d490',1,'spi_init(void):&#160;nrf24_avr.c']]],
  ['spi_5ftransfer_4',['spi_transfer',['../carrinho_2nrf24__avr_8c.html#a8d161d483c095113df5b69798e9cd725',1,'spi_transfer(uint8_t data):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a8d161d483c095113df5b69798e9cd725',1,'spi_transfer(uint8_t data):&#160;nrf24_avr.c']]],
  ['sprintf_5fp_5',['sprintf_P',['../carrinho_2RF24__config_8h.html#a6120d1982a91bb372fbee1502841baba',1,'sprintf_P:&#160;RF24_config.h'],['../controle_2RF24__config_8h.html#a6120d1982a91bb372fbee1502841baba',1,'sprintf_P:&#160;RF24_config.h']]],
  ['status_5freg_6',['status_reg',['../carrinho_2nrf24__avr_8c.html#a7fe1e45a5bfd9d243fc5713c3a8f1bb0',1,'status_reg:&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a7fe1e45a5bfd9d243fc5713c3a8f1bb0',1,'status_reg:&#160;nrf24_avr.c']]],
  ['sw_7',['sw',['../structControls.html#a14d0fa1de5e626d1dc1cba236dff2379',1,'Controls']]]
];
