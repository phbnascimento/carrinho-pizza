var searchData=
[
  ['status_5freg_0',['status_reg',['../carrinho_2nrf24__avr_8c.html#a7fe1e45a5bfd9d243fc5713c3a8f1bb0',1,'status_reg:&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a7fe1e45a5bfd9d243fc5713c3a8f1bb0',1,'status_reg:&#160;nrf24_avr.c']]],
  ['sw_1',['sw',['../structControls.html#a14d0fa1de5e626d1dc1cba236dff2379',1,'Controls']]]
];
