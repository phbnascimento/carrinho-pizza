var searchData=
[
  ['trigger_0',['TRIGGER',['../controle__ino_8ino.html#a86de85f5177dabb5ff712bf180db43aa',1,'TRIGGER:&#160;controle_ino.ino'],['../controle_8c.html#a86de85f5177dabb5ff712bf180db43aa',1,'TRIGGER:&#160;controle.c']]],
  ['tx_5faddr_1',['TX_ADDR',['../carrinho_2nRF24L01_8h.html#aa734c6e08b9f794436eacbabe466a6c4',1,'TX_ADDR:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#aa734c6e08b9f794436eacbabe466a6c4',1,'TX_ADDR:&#160;nRF24L01.h']]],
  ['tx_5fds_2',['TX_DS',['../carrinho_2nRF24L01_8h.html#ab5f5243908a39ffd514fe701e9749bdc',1,'TX_DS:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#ab5f5243908a39ffd514fe701e9749bdc',1,'TX_DS:&#160;nRF24L01.h']]],
  ['tx_5fempty_3',['TX_EMPTY',['../carrinho_2nRF24L01_8h.html#ae4034d6a21b6646c8710d09e43bd9383',1,'TX_EMPTY:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#ae4034d6a21b6646c8710d09e43bd9383',1,'TX_EMPTY:&#160;nRF24L01.h']]],
  ['tx_5ffull_4',['TX_FULL',['../carrinho_2nRF24L01_8h.html#af3b1baf3a7a57b7471443d1ff002c778',1,'TX_FULL:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#af3b1baf3a7a57b7471443d1ff002c778',1,'TX_FULL:&#160;nRF24L01.h']]],
  ['tx_5freuse_5',['TX_REUSE',['../carrinho_2nRF24L01_8h.html#a506a58de7b75af27e3745db3e1e9733c',1,'TX_REUSE:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a506a58de7b75af27e3745db3e1e9733c',1,'TX_REUSE:&#160;nRF24L01.h']]]
];
