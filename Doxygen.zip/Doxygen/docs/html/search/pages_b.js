var searchData=
[
  ['🚀_20como_20compilar_0',['🚀 Como Compilar',['../index.html#autotoc_md8',1,'']]]
];
