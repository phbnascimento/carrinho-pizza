var searchData=
[
  ['write_5fpayload_0',['write_payload',['../carrinho_2nrf24__avr_8c.html#a3c9fd94e9894bf0792d4ff5891c16436',1,'write_payload(const void *buf, uint8_t len, uint8_t writeType):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a3c9fd94e9894bf0792d4ff5891c16436',1,'write_payload(const void *buf, uint8_t len, uint8_t writeType):&#160;nrf24_avr.c']]],
  ['write_5freg_1',['write_reg',['../carrinho_2nrf24__avr_8c.html#a08bc978021db604d02a6da754f73e7e2',1,'write_reg(uint8_t reg, const uint8_t *buf, uint8_t len):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a08bc978021db604d02a6da754f73e7e2',1,'write_reg(uint8_t reg, const uint8_t *buf, uint8_t len):&#160;nrf24_avr.c']]]
];
