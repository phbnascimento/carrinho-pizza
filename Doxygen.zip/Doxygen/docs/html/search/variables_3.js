var searchData=
[
  ['duration_0',['duration',['../structTimer.html#a11ac07bbdfcc4f8380046f5b6f542703',1,'Timer::duration'],['../structTimer.html#a4b6d034aafbb34e214d5d5aa01c8a234',1,'Timer::duration']]],
  ['dynamic_5fpayloads_1',['dynamic_payloads',['../carrinho_2nrf24__avr_8c.html#a41244788e3cbede528185aca2e752059',1,'dynamic_payloads:&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a41244788e3cbede528185aca2e752059',1,'dynamic_payloads:&#160;nrf24_avr.c']]]
];
