var searchData=
[
  ['carro_20pizza_20🚗_0',['Gigantes de MDF - CARRO-PIZZA! 🚗',['../index.html',1,'']]],
  ['como_20compilar_1',['🚀 Como Compilar',['../index.html#autotoc_md8',1,'']]],
  ['compilar_2',['🚀 Como Compilar',['../index.html#autotoc_md8',1,'']]]
];
