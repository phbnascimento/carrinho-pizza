var searchData=
[
  ['setup_0',['setup',['../carrinho__ino_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;carrinho_ino.ino'],['../controle__ino_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;controle_ino.ino'],['../controle_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;controle.c']]],
  ['spi_5finit_1',['spi_init',['../carrinho_2nrf24__avr_8c.html#aa653f4dc3541758224a53eef3f04d490',1,'spi_init(void):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#aa653f4dc3541758224a53eef3f04d490',1,'spi_init(void):&#160;nrf24_avr.c']]],
  ['spi_5ftransfer_2',['spi_transfer',['../carrinho_2nrf24__avr_8c.html#a8d161d483c095113df5b69798e9cd725',1,'spi_transfer(uint8_t data):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a8d161d483c095113df5b69798e9cd725',1,'spi_transfer(uint8_t data):&#160;nrf24_avr.c']]]
];
