var searchData=
[
  ['trigger_0',['trigger',['../structControls.html#acf3f4cb783a1d6a1acbd0f3656620b7b',1,'Controls']]]
];
