var searchData=
[
  ['pll_5flock_0',['PLL_LOCK',['../carrinho_2nRF24L01_8h.html#af76cfc0d6ed71259b4a237cbd8e30624',1,'PLL_LOCK:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#af76cfc0d6ed71259b4a237cbd8e30624',1,'PLL_LOCK:&#160;nRF24L01.h']]],
  ['plos_5fcnt_1',['PLOS_CNT',['../carrinho_2nRF24L01_8h.html#af45c13e8941613c7eb931001ab964965',1,'PLOS_CNT:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#af45c13e8941613c7eb931001ab964965',1,'PLOS_CNT:&#160;nRF24L01.h']]],
  ['prim_5frx_2',['PRIM_RX',['../carrinho_2nRF24L01_8h.html#a0b4d92f3ecccb150d4cb1cb5d0f9d4e6',1,'PRIM_RX:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a0b4d92f3ecccb150d4cb1cb5d0f9d4e6',1,'PRIM_RX:&#160;nRF24L01.h']]],
  ['pwr_5fup_3',['PWR_UP',['../carrinho_2nRF24L01_8h.html#af0dbd9e4c17ba0db357fcb2cedd4aa6d',1,'PWR_UP:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#af0dbd9e4c17ba0db357fcb2cedd4aa6d',1,'PWR_UP:&#160;nRF24L01.h']]]
];
