var searchData=
[
  ['_5fce_5fpin_0',['_ce_pin',['../carrinho_2nrf24__avr_8c.html#a4825d22c5c1a40f8e9b62e3073cd3aad',1,'_ce_pin:&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a4825d22c5c1a40f8e9b62e3073cd3aad',1,'_ce_pin:&#160;nrf24_avr.c']]],
  ['_5fcsn_5fpin_1',['_csn_pin',['../carrinho_2nrf24__avr_8c.html#aeb1e8024b2a72dd816eeafc9dc4a8698',1,'_csn_pin:&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#aeb1e8024b2a72dd816eeafc9dc4a8698',1,'_csn_pin:&#160;nrf24_avr.c']]]
];
