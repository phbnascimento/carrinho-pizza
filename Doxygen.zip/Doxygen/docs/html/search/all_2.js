var searchData=
[
  ['backwards_0',['BACKWARDS',['../carrinho__ino_8ino.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4aad5aa01ac1825d55dfc1978ee49c4c36',1,'BACKWARDS:&#160;carrinho_ino.ino'],['../carrinho_8c.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4aad5aa01ac1825d55dfc1978ee49c4c36',1,'BACKWARDS:&#160;carrinho.c']]],
  ['btn_1',['BTN',['../carrinho__ino_8ino.html#ad475217c28645ec178b59c745f3fc3ba',1,'BTN:&#160;carrinho_ino.ino'],['../carrinho_8c.html#ad475217c28645ec178b59c745f3fc3ba',1,'BTN:&#160;carrinho.c']]]
];
