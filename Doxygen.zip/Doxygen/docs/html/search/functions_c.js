var searchData=
[
  ['timer_5ftick_0',['timer_tick',['../carrinho_8c.html#a1d20445f4dfe5c6183e929ef7221d4d4',1,'carrinho.c']]],
  ['timerreset_1',['timerReset',['../carrinho__ino_8ino.html#a28e17ddfc6c506e94ffac4c672837624',1,'timerReset(Timer *timer):&#160;carrinho_ino.ino'],['../carrinho_8c.html#a8019f056ad898f0e555eb56190617c2b',1,'timerReset(Timer *t):&#160;carrinho.c']]]
];
