var searchData=
[
  ['right_0',['RIGHT',['../carrinho__ino_8ino.html#a3bc45ff9023afee0cc287274e972d7ceaec8379af7490bb9eaaf579cf17876f38',1,'RIGHT:&#160;carrinho_ino.ino'],['../carrinho_8c.html#a3bc45ff9023afee0cc287274e972d7ceaec8379af7490bb9eaaf579cf17876f38',1,'RIGHT:&#160;carrinho.c']]]
];
