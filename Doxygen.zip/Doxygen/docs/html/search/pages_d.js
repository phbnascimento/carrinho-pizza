var searchData=
[
  ['🛠️_20hardware_20utilizado_0',['🛠️ Hardware Utilizado',['../index.html#autotoc_md4',1,'']]]
];
