var searchData=
[
  ['radio_0',['radio',['../carrinho__ino_8ino.html#a53cdd46f95419ffdcd44d3f0d6147b54',1,'radio(9, 10):&#160;carrinho_ino.ino'],['../controle__ino_8ino.html#a53cdd46f95419ffdcd44d3f0d6147b54',1,'radio(9, 10):&#160;controle_ino.ino']]],
  ['read_5fpayload_1',['read_payload',['../carrinho_2nrf24__avr_8c.html#ac4a676257b5b86b05f4ea608636cb2cf',1,'read_payload(void *buf, uint8_t len):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#ac4a676257b5b86b05f4ea608636cb2cf',1,'read_payload(void *buf, uint8_t len):&#160;nrf24_avr.c']]],
  ['read_5freg_2',['read_reg',['../carrinho_2nrf24__avr_8c.html#abefdb1d58b989853c0646a6c8b18b7d3',1,'read_reg(uint8_t reg):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#abefdb1d58b989853c0646a6c8b18b7d3',1,'read_reg(uint8_t reg):&#160;nrf24_avr.c']]],
  ['read_5freg_5fbuf_3',['read_reg_buf',['../carrinho_2nrf24__avr_8c.html#a31d6889b046799ad06c03ce52c9bb640',1,'read_reg_buf(uint8_t reg, uint8_t *buf, uint8_t len):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a31d6889b046799ad06c03ce52c9bb640',1,'read_reg_buf(uint8_t reg, uint8_t *buf, uint8_t len):&#160;nrf24_avr.c']]]
];
