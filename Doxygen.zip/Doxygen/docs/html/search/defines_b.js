var searchData=
[
  ['nrf_5fconfig_0',['NRF_CONFIG',['../carrinho_2nRF24L01_8h.html#ab365e330ce094a191c25fdf1d3f64a94',1,'NRF_CONFIG:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#ab365e330ce094a191c25fdf1d3f64a94',1,'NRF_CONFIG:&#160;nRF24L01.h']]],
  ['nrf_5fstatus_1',['NRF_STATUS',['../carrinho_2nRF24L01_8h.html#a62c8d1dc6bd80fb70c17ef9de6d49cd2',1,'NRF_STATUS:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a62c8d1dc6bd80fb70c17ef9de6d49cd2',1,'NRF_STATUS:&#160;nRF24L01.h']]]
];
