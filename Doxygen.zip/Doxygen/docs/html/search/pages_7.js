var searchData=
[
  ['pinagem_20pinout_0',['🔌 Pinagem (Pinout)',['../index.html#autotoc_md6',1,'']]],
  ['pinout_1',['🔌 Pinagem (Pinout)',['../index.html#autotoc_md6',1,'']]],
  ['pizza_20🚗_2',['Gigantes de MDF - CARRO-PIZZA! 🚗',['../index.html',1,'']]]
];
