var searchData=
[
  ['btn_0',['BTN',['../carrinho__ino_8ino.html#ad475217c28645ec178b59c745f3fc3ba',1,'BTN:&#160;carrinho_ino.ino'],['../carrinho_8c.html#ad475217c28645ec178b59c745f3fc3ba',1,'BTN:&#160;carrinho.c']]]
];
