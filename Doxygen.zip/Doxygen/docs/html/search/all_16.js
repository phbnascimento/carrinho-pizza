var searchData=
[
  ['y_0',['y',['../structControls.html#a8a1da9fdf679e6e1d17f310420755d94',1,'Controls']]]
];
