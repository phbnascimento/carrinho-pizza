var searchData=
[
  ['objetivos_0',['🎯 Objetivos',['../index.html#autotoc_md2',1,'']]]
];
