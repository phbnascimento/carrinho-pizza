var searchData=
[
  ['🔌_20pinagem_20pinout_0',['🔌 Pinagem (Pinout)',['../index.html#autotoc_md6',1,'']]]
];
