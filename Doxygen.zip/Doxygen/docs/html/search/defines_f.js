var searchData=
[
  ['setup_5faw_0',['SETUP_AW',['../carrinho_2nRF24L01_8h.html#af5ef355ba3eca336db1285cab353ddc2',1,'SETUP_AW:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#af5ef355ba3eca336db1285cab353ddc2',1,'SETUP_AW:&#160;nRF24L01.h']]],
  ['setup_5fretr_1',['SETUP_RETR',['../carrinho_2nRF24L01_8h.html#a2188309b3eceeae158dd64109cd919aa',1,'SETUP_RETR:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a2188309b3eceeae158dd64109cd919aa',1,'SETUP_RETR:&#160;nRF24L01.h']]],
  ['sprintf_5fp_2',['sprintf_P',['../carrinho_2RF24__config_8h.html#a6120d1982a91bb372fbee1502841baba',1,'sprintf_P:&#160;RF24_config.h'],['../controle_2RF24__config_8h.html#a6120d1982a91bb372fbee1502841baba',1,'sprintf_P:&#160;RF24_config.h']]]
];
