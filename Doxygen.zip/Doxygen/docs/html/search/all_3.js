var searchData=
[
  ['carrinho_2ec_0',['carrinho.c',['../carrinho_8c.html',1,'']]],
  ['carrinho_5fino_2eino_1',['carrinho_ino.ino',['../carrinho__ino_8ino.html',1,'']]],
  ['carro_20pizza_20🚗_2',['Gigantes de MDF - CARRO-PIZZA! 🚗',['../index.html',1,'']]],
  ['cd_3',['CD',['../carrinho_2nRF24L01_8h.html#a1050140a3d78b059f809a424e0d9e1c7',1,'CD:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a1050140a3d78b059f809a424e0d9e1c7',1,'CD:&#160;nRF24L01.h']]],
  ['ce_5fhigh_4',['ce_high',['../carrinho_2nrf24__avr_8c.html#a5336963072afb877d785bed84eb6b5f4',1,'ce_high(void):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a5336963072afb877d785bed84eb6b5f4',1,'ce_high(void):&#160;nrf24_avr.c']]],
  ['ce_5flow_5',['ce_low',['../carrinho_2nrf24__avr_8c.html#a77c5f7c57c01266d04faea3052a47f49',1,'ce_low(void):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a77c5f7c57c01266d04faea3052a47f49',1,'ce_low(void):&#160;nrf24_avr.c']]],
  ['ce_5fpin_6',['CE_PIN',['../main_8c.html#abb388c9dfbdca89b280a12c4af1a030f',1,'main.c']]],
  ['como_20compilar_7',['🚀 Como Compilar',['../index.html#autotoc_md8',1,'']]],
  ['compilar_8',['🚀 Como Compilar',['../index.html#autotoc_md8',1,'']]],
  ['cont_5fwave_9',['CONT_WAVE',['../carrinho_2nRF24L01_8h.html#a165f18ecbab7e3f232eeba3dbcd028d0',1,'CONT_WAVE:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a165f18ecbab7e3f232eeba3dbcd028d0',1,'CONT_WAVE:&#160;nRF24L01.h']]],
  ['controle_2ec_10',['controle.c',['../controle_8c.html',1,'']]],
  ['controle_5fino_2eino_11',['controle_ino.ino',['../controle__ino_8ino.html',1,'']]],
  ['controls_12',['Controls',['../structControls.html',1,'']]],
  ['count_13',['count',['../structTimer.html#ae4991a745c62a2919e8be3d17f14fbf1',1,'Timer::count'],['../structTimer.html#a37a2a0ce03e0cfe3180159e35eebf60e',1,'Timer::count']]],
  ['crco_14',['CRCO',['../carrinho_2nRF24L01_8h.html#a253dd73b17f0ea7f71e55f52e796836a',1,'CRCO:&#160;nRF24L01.h'],['../controle_2nRF24L01_8h.html#a253dd73b17f0ea7f71e55f52e796836a',1,'CRCO:&#160;nRF24L01.h']]],
  ['csn_5fhigh_15',['csn_high',['../carrinho_2nrf24__avr_8c.html#adaef88bc02a8e805de3b3a82bf317549',1,'csn_high(void):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#adaef88bc02a8e805de3b3a82bf317549',1,'csn_high(void):&#160;nrf24_avr.c']]],
  ['csn_5flow_16',['csn_low',['../carrinho_2nrf24__avr_8c.html#a42f8c1120431b7c37e116a4e1eac1cc2',1,'csn_low(void):&#160;nrf24_avr.c'],['../controle_2nrf24__avr_8c.html#a42f8c1120431b7c37e116a4e1eac1cc2',1,'csn_low(void):&#160;nrf24_avr.c']]],
  ['csn_5fpin_17',['CSN_PIN',['../main_8c.html#a6c4d73944fe1bd2ff7ceee867c315ac1',1,'main.c']]]
];
