var searchData=
[
  ['istimerover_0',['isTimerOver',['../carrinho__ino_8ino.html#adf1dfbee680be7fd774683d7c6a1a05c',1,'isTimerOver(Timer timer):&#160;carrinho_ino.ino'],['../carrinho_8c.html#a77947cc1d2af5b57aa9e7f701e2c1f51',1,'isTimerOver(Timer t):&#160;carrinho.c']]]
];
