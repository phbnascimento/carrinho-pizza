var annotated_dup =
[
    [ "Controls", "structControls.html", "structControls" ],
    [ "Timer", "structTimer.html", "structTimer" ]
];