var codigo_8c =
[
    [ "Controls", "structControls.html", "structControls" ],
    [ "BTN", "codigo_8c.html#ad475217c28645ec178b59c745f3fc3ba", null ],
    [ "ENA", "codigo_8c.html#ac20176fb102e81762b5bb8a08b65a206", null ],
    [ "ENB", "codigo_8c.html#afb4da94c34e8eeb6ebb83676d92ea36b", null ],
    [ "F_CPU", "codigo_8c.html#a43bafb28b29491ec7f871319b5a3b2f8", null ],
    [ "HIGH", "codigo_8c.html#a5bb885982ff66a2e0a0a45a8ee9c35e2", null ],
    [ "IN1", "codigo_8c.html#aa118db89564189dcf8c48ecbd79937d8", null ],
    [ "IN2", "codigo_8c.html#ac2c663eb7de5a963911af77b65451fb6", null ],
    [ "IN3", "codigo_8c.html#ae24e8a55f5b9660a35dc5cf8a5e8ba4a", null ],
    [ "IN4", "codigo_8c.html#a38caa48612155e36696b60d2aabc25ff", null ],
    [ "IS_PRESSED", "codigo_8c.html#a60858d59aa9fd54683018c3023970db5", null ],
    [ "LASER", "codigo_8c.html#a7ec8393e9445109104fd54119e06fc08", null ],
    [ "LDR", "codigo_8c.html#a9fa6f083fd9b05ac8a6b94f34322661e", null ],
    [ "LED", "codigo_8c.html#a94180201817e497ad4f773021adf385b", null ],
    [ "LED1", "codigo_8c.html#a8aa85ae9867fabf70ec72cd3bf6fb6b9", null ],
    [ "LED2", "codigo_8c.html#ad09fe5bf321b9a2de26bd5e5b9af6424", null ],
    [ "LED3", "codigo_8c.html#a4b7ff8e253a7412f83deba3a447028a8", null ],
    [ "LOW", "codigo_8c.html#ab811d8c6ff3a505312d3276590444289", null ],
    [ "Dir", "codigo_8c.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4", [
      [ "BACKWARDS", "codigo_8c.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4aad5aa01ac1825d55dfc1978ee49c4c36", null ],
      [ "FORWARD", "codigo_8c.html#a7cf6e8c5a5bc5e7b2afef3647870b1c4aa26736999186daf8146f809e863712a1", null ]
    ] ],
    [ "Motor", "codigo_8c.html#a3bc45ff9023afee0cc287274e972d7ce", [
      [ "LEFT", "codigo_8c.html#a3bc45ff9023afee0cc287274e972d7ceadb45120aafd37a973140edee24708065", null ],
      [ "RIGHT", "codigo_8c.html#a3bc45ff9023afee0cc287274e972d7ceaec8379af7490bb9eaaf579cf17876f38", null ]
    ] ],
    [ "abs", "codigo_8c.html#aaa87dddb1e62142fd07ee17db1b5d673", null ],
    [ "analog_read", "codigo_8c.html#a08bebecdd1ca2d6e7ef3f68cd452ccf9", null ],
    [ "analog_setup", "codigo_8c.html#a1fc0a8f5b026eb5e606e738ca5434d2d", null ],
    [ "analog_write", "codigo_8c.html#ac7c0935e24e573b2929d0df7f9e6b82f", null ],
    [ "gameOver", "codigo_8c.html#a026d019671eda0cfe729200fc24d23ba", null ],
    [ "loop", "codigo_8c.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "main", "codigo_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "motor", "codigo_8c.html#a83f9abde8522ce95dd4c5ce5ba3d9d39", null ],
    [ "addr", "codigo_8c.html#a0d5aeb028158bc168b01ed3bf2a385be", null ],
    [ "life", "codigo_8c.html#a5694338c1bcb4455072af4179913d44d", null ],
    [ "on", "codigo_8c.html#aaa928c9a62449f7946da1e32f66c70d2", null ],
    [ "pressed", "codigo_8c.html#a132ba96da5ba28448b61e42c019312a9", null ],
    [ "prev", "codigo_8c.html#af2f56090dc8a3b112529c55e98dd04a7", null ]
];