var carrinho_2nrf24__avr_8h =
[
    [ "nrf24_available", "carrinho_2nrf24__avr_8h.html#a0f64caa74329fd5799a33f30bd8ebf82", null ],
    [ "nrf24_begin", "carrinho_2nrf24__avr_8h.html#ab6fb4c1aa834152310116e7dec65d8e3", null ],
    [ "nrf24_flush_rx", "carrinho_2nrf24__avr_8h.html#a9351c150d32184a95db9ab4a802ed860", null ],
    [ "nrf24_flush_tx", "carrinho_2nrf24__avr_8h.html#a617ab4b2604d6f482796e35da85369ad", null ],
    [ "nrf24_getStatus", "carrinho_2nrf24__avr_8h.html#a9a23f602a6077c795322702d0a42f48c", null ],
    [ "nrf24_init_hwspi", "carrinho_2nrf24__avr_8h.html#a023289d1e49bf7f3b61e0e1c5312c8cf", null ],
    [ "nrf24_openReadingPipe", "carrinho_2nrf24__avr_8h.html#a5af2f11537aed8a56d8489355af0ff16", null ],
    [ "nrf24_openWritingPipe", "carrinho_2nrf24__avr_8h.html#a21d638882f746748de35324bdc21f448", null ],
    [ "nrf24_read", "carrinho_2nrf24__avr_8h.html#aa0767db791fc0b45ebadab011c1900bf", null ],
    [ "nrf24_setChannel", "carrinho_2nrf24__avr_8h.html#a49aa88b1042d6d62114cfbca271d9e2b", null ],
    [ "nrf24_setPayloadSize", "carrinho_2nrf24__avr_8h.html#aaf2900e7932ebbf7f0ecdc6bce5840e1", null ],
    [ "nrf24_startListening", "carrinho_2nrf24__avr_8h.html#a71c5628e9583f6a6fd0871b3ae1bf6df", null ],
    [ "nrf24_stopListening", "carrinho_2nrf24__avr_8h.html#a33899bc3c0f4d2293f37c306d0b8e297", null ],
    [ "nrf24_write", "carrinho_2nrf24__avr_8h.html#a8232e1982aabc6f52408c318402cb578", null ]
];